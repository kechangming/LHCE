#!/bin/bash
export PATH=/PARA/blsc828/cmk/vasp_package/vasp.6.1.0/bin:$PATH
module load MPI/Intel/MPICH/3.2-icc2017-dyn
work_directory=`pwd` 
# trilayer
yhrun -e err.vasp -o %J.out -p paratera -n 576 -N 24 -J LiFSI-THF vasp_gam_O3 &
