#! /bin/bash

work_directory="/public3/home/sc54385/cmk/wang_group/electrolyte_dilute"
INCAR="/public3/home/sc54385/cmk/wang_group/electrolyte_dilute/INCAR"
KPOINTS="/public3/home/sc54385/cmk/wang_group/electrolyte_dilute/KPOINTS"
pot_directory="/public3/home/sc54385/cmk/potpaw_PBE.54"

for directory in LiPF6
do
cd ${work_directory}/${directory}
#pwd
for molecule in PhOH THF
do

cd ${work_directory}/${directory}/$molecule
#cp CONTCAR POSCAR
#cp ${molecule}.vasp POSCAR
#rm *.out
srun -e err.vasp -o %J.out -p amd_256 -n 64 -J $molecule vasp_gam &
sleep 1
#pwd
#rm *
done
done

